//
//  FileManager.h
//  Sample
//
//  Created by Agility Logistics on 18/09/13.
//  Copyright (c) 2013 Sukanya. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FileManager : UIViewController
{
    IBOutlet UITableView *myTable;
    NSMutableArray  *arr_List;
}

@end
