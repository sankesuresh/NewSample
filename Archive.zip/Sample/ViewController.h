//
//  ViewController.h
//  Sample
//
//  Created by Agility Logistics on 11/09/13.
//  Copyright (c) 2013 Sukanya. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
{
    IBOutlet UITextField *txtNo,*txtName;
}

@end
